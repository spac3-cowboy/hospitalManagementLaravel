/**
     * Display a listing of the {{ $config->modelNames->plural }}.
     * GET|HEAD /{{ $config->modelNames->dashedPlural }}
     */
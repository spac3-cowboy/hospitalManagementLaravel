<?php

return [
    'retrieved' => ':model berhasil diambil.',
    'saved'     => ':model berhasil disimpan.',
    'updated'   => ':model berhasil diperbarui.',
    'deleted'   => ':model berhasil dihapus.',
    'not_found' => ':model tidak ditemukan',
];

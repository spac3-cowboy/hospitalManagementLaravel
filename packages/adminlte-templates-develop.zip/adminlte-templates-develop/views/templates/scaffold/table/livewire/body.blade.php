<div class="card-body">
                @@livewire('{{ $config->modelNames->dashedPlural }}-table', [])
            </div>
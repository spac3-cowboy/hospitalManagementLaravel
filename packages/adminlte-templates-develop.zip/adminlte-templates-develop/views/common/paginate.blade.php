<div class="row">
    {!! $records->links() !!}
</div>

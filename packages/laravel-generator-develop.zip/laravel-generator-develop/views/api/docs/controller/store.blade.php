/**
     * Store a newly created {{ $config->modelNames->name }} in storage.
     * POST /{{ $config->modelNames->dashedPlural }}
     */
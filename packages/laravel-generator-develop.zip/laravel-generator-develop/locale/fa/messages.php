<?php

return [

    'retrieved' => ':model با موفقیت بازیابی شد',
    'saved'     => ':model با موفقیت ذخیره شد.',
    'updated'   => ':model با موفقیت به روز شد.',
    'deleted'   => ':model با موفقیت حذف شد',
    'not_found' => ':model پیدا نشد',

];

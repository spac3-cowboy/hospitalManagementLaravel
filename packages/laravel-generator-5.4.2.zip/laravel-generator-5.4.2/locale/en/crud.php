<?php

return [

    'add_new'      => 'Add New',
    'cancel'       => 'Cancel',
    'create'       => 'Create',
    'edit'         => 'Edit',
    'save'         => 'Save',
    'delete'       => 'Delete',
    'detail'       => 'Detail',
    'back'         => 'Back',
    'search'       => 'Search',
    'export'       => 'Export',
    'print'        => 'Print',
    'reset'        => 'Reset',
    'reload'       => 'Reload',
    'action'       => 'Action',
    'id'           => 'Id',
    'created_at'   => 'Created At',
    'updated_at'   => 'Updated At',
    'deleted_at'   => 'Deleted At',
    'are_you_sure' => 'Are you sure?',
];

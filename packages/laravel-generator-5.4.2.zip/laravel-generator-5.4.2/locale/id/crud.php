<?php

return [

    'add_new'      => 'Tambah baru',
    'cancel'       => 'Membatalkan',
    'create'       => 'Membuat',
    'edit'         => 'Sunting',
    'save'         => 'Menyimpan',
    'detail'       => 'Detail',
    'back'         => 'Kembali',
    'search'       => 'Mencari',
    'export'       => 'Ekspor',
    'print'        => 'Mencetak',
    'reset'        => 'Mengatur ulang',
    'reload'       => 'Muat ulang',
    'action'       => 'Tindakan',
    'id'           => 'Indo',
    'created_at'   => 'Dibuat di',
    'updated_at'   => 'Diperbarui Pada',
    'deleted_at'   => 'Dihapus At',
    'are_you_sure' => 'Apa kamu yakin?',
];

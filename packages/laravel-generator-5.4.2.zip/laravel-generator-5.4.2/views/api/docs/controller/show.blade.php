/**
     * Display the specified {{ $config->modelNames->name }}.
     * GET|HEAD /{{ $config->modelNames->dashedPlural }}/{id}
     */
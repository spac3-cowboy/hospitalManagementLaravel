/**
     * Remove the specified {{ $config->modelNames->name }} from storage.
     * DELETE /{{ $config->modelNames->dashedPlural }}/{id}
     *
     * @throws \Exception
     */
/**
 * Class {{ $config->modelNames->name }}APIController
 */
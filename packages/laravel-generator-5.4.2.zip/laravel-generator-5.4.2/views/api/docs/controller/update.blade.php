/**
     * Update the specified {{ $config->modelNames->name }} in storage.
     * PUT/PATCH /{{ $config->modelNames->dashedPlural }}/{id}
     */
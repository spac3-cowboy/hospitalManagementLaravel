<?php

namespace InfyOm\Generator\DTOs;

class ModelNames
{
    public string $name;
    public string $plural;
    public string $camel;
    public string $camelPlural;
    public string $snake;
    public string $snakePlural;
    public string $dashed;
    public string $dashedPlural;
    public string $human;
    public string $humanPlural;
}

<?php

namespace Rappasoft\LaravelLivewireTables\Exceptions;

class DataTableConfigurationException extends \Exception
{
}
